# MyFirstPackage
This libarary was created as an example on how to create a package and publish it to GitHub

## building this package locally
'python setup.py sdist'

## installing this package from GitHub

## updating the package from GitHub